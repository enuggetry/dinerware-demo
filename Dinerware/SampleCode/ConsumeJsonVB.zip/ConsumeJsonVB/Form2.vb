﻿Imports System.Net

Public Class Form2
    Public _GeonamesUser As String

    Public Sub Init(ByRef data As PanoramioData, ByRef geonamesUser As String)
        _GeonamesUser = geonamesUser
        lblInfo.Text = String.Format(lblInfo.Text, data.count)
        Dim x As Integer = 0
        Dim y As Integer = 0
        Dim dist As Integer = 120
        Dim maxX As Integer = 4
        For Each photo As Photo In data.photos
            'show the photo
            Dim pic As PictureBox = New PictureBox()

            'adjust the table size...
            If photo.width > (dist - 20) Then
                dist = photo.width + 20
            End If

            If photo.height > (dist - 20) Then
                dist = photo.height + 20
            End If

            pic.Location = New Point(10 + x * dist, 40 + y * (dist + 20))
            pic.Size = New Size(photo.width, photo.height)
            pic.Tag = photo
            Me.Controls.Add(pic)
            'PictureBox can load from the web
            pic.ImageLocation = photo.photo_file_url
            AddHandler pic.DoubleClick, AddressOf Photo_DoubleClick
            AddHandler pic.MouseEnter, AddressOf Photo_MouseEnter
            AddHandler pic.MouseLeave, AddressOf Photo_MouseLeave

            'a link to the Author
            Dim label As LinkLabel = New LinkLabel()
            label.Text = String.Format("Author: {0}", photo.owner_name)
            label.Links.Add(0, label.Text.Length, photo.owner_url)
            label.Location = New Point(pic.Left, pic.Top + pic.Height)
            label.Size = New Size(dist, 15)
            Me.Controls.Add(label)
            AddHandler label.LinkClicked, AddressOf LinkClicked

            'Button for places and toponyms
            Dim btnPlace As Button = New Button()
            btnPlace.Size = New Size(CInt(pic.Width / 2), 20)
            btnPlace.Text = "Place"
            btnPlace.Location = New Point(label.Left, label.Top + label.Height)
            btnPlace.Tag = photo
            Me.Controls.Add(btnPlace)
            AddHandler btnPlace.Click, AddressOf btnPlace_Click

            Dim btnTopo As Button = New Button()
            btnTopo.Size = New Size(CInt(pic.Width / 2), 20)
            btnTopo.Text = "Toponym"
            btnTopo.Location = New Point(CInt(label.Left + pic.Width / 2), label.Top + label.Height)
            btnTopo.Tag = photo
            Me.Controls.Add(btnTopo)
            AddHandler btnTopo.Click, AddressOf btnTopo_Click

            'count columns and rows
            x = x + 1
            If x > maxX Then
                x = 0
                y = y + 1
            End If
        Next
    End Sub

    Private Sub Photo_DoubleClick(ByVal sender As Object, ByVal e As EventArgs)
        'open the photo in the default web browser
        Try
            Dim pic As PictureBox = CType(sender, PictureBox)
            If Not pic Is Nothing Then
                Dim photo As Photo = CType(pic.Tag, Photo)
                If Not photo Is Nothing Then
                    If Not String.IsNullOrEmpty(photo.photo_url) Then
                        System.Diagnostics.Process.Start(photo.photo_url)
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Sub Photo_MouseEnter(ByVal sender As Object, ByVal e As EventArgs)
        'set tooltip: show the photo title
        Try
            Dim pic As PictureBox = CType(sender, PictureBox)
            If Not pic Is Nothing Then
                Dim photo As Photo = CType(pic.Tag, Photo)
                If Not photo Is Nothing Then
                    ToolTip1.SetToolTip(pic, photo.photo_title)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Sub Photo_MouseLeave(ByVal sender As Object, ByVal e As EventArgs)
        'reset tooltip
        Try
            ToolTip1.RemoveAll()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Sub LinkClicked(ByVal sender As Object, ByVal e As LinkLabelLinkClickedEventArgs)
        'open the URL to the owner of the photo in the default web browser
        Try
            Dim label As LinkLabel = CType(sender, LinkLabel)
            If Not label Is Nothing Then
                label.Links(label.Links.IndexOf(e.Link)).Visited = True
                System.Diagnostics.Process.Start(e.Link.LinkData.ToString())
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Sub btnPlace_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Dim photo As Photo = CType(CType(sender, Button).Tag, Photo)
            'http://api.geonames.org/findNearbyPlaceNameJSON?lat=47.3&lng=9&username=demo
            Dim url As String = String.Format("http://api.geonames.org/findNearbyPlaceNameJSON?lat={0}&lng={1}&username={2}", photo.latitude, photo.longitude, _GeonamesUser)

            Dim geonames As Geonames = GetGeonames(url)
            If geonames Is Nothing Then
                'some problem happened, and it was handled already
                Return
            ElseIf geonames.geonames.Count = 0 Then
                MessageBox.Show("The service found no place nearby.", "No results")
            Else
                Dim geoname As Geoname = geonames.geonames(0)
                Dim msgResult As String = "The service found following toponym nearby:" + vbCrLf
                msgResult += "Name:" + vbTab + vbTab + geoname.name + vbCrLf
                msgResult += "Country:" + vbTab + vbTab + geoname.countryName + vbCrLf
                msgResult += "Province:" + vbTab + vbTab + geoname.adminName1 + vbCrLf
                msgResult += "Population:" + vbTab + geoname.population.ToString() + vbCrLf
                msgResult += "Distance:" + vbTab + vbTab + geoname.distance + " km"
                MessageBox.Show(msgResult, "Result")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Sub btnTopo_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            Dim photo As Photo = CType(CType(sender, Button).Tag, Photo)
            'http://api.geonames.org/findNearbyJSON?lat=47.3&lng=9&username=demo
            Dim url As String = String.Format("http://api.geonames.org/findNearbyJSON?lat={0}&lng={1}&username={2}", photo.latitude, photo.longitude, _GeonamesUser)

            Dim geonames As Geonames = GetGeonames(url)
            If geonames Is Nothing Then
                Return
            ElseIf geonames.geonames.Count = 0 Then
                MessageBox.Show("The service found no toponym nearby.", "No results")
            Else
                Dim geoname As Geoname = geonames.geonames(0)
                Dim msgResult As String = "The service found following toponym nearby:" + vbCrLf
                msgResult += "Name:" + vbTab + geoname.name + vbCrLf
                msgResult += "Country:" + vbTab + geoname.countryName + vbCrLf
                msgResult += "Province:" + vbTab + geoname.adminName1 + vbCrLf
                msgResult += "Distance:" + vbTab + geoname.distance + " km"
                MessageBox.Show(msgResult, "Result")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "BUG!")
        End Try
    End Sub

    Private Function GetGeonames(ByVal url As String) As Geonames
        Dim request As WebRequest = WebRequest.Create(url)
        Dim ws As WebResponse = request.GetResponse()

        Dim jsonString As String = String.Empty
        Using sreader As System.IO.StreamReader = New System.IO.StreamReader(ws.GetResponseStream())
            jsonString = sreader.ReadToEnd()
        End Using
        Dim jsSerializer As System.Web.Script.Serialization.JavaScriptSerializer = New System.Web.Script.Serialization.JavaScriptSerializer()
        Dim geonames As Geonames = jsSerializer.Deserialize(Of Geonames)(jsonString)
        'in case of an exception, geonames.geonames is null
        If (geonames Is Nothing Or geonames.geonames Is Nothing) Then
            'hence we expect a message with the exception
            Dim stat As StatusRootObject = jsSerializer.Deserialize(Of StatusRootObject)(jsonString)
            If (Not stat Is Nothing And Not stat.status Is Nothing) Then
                Dim msg As String = "The web service did not like your request." + vbCrLf
                msg += "The return code is " + stat.status.value.ToString() + "." + vbCrLf
                msg += "The message is: " + vbCrLf + stat.status.message
                MessageBox.Show(msg, "Bad Request!")
            Else
                Dim msg As String = "The server returned an unexpected response:" + vbCrLf
                msg += jsonString
                MessageBox.Show(msg, "Unexpected Response!")
            End If
            Return Nothing
        End If
        Return geonames
    End Function
End Class