﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtGeonamesUser = New System.Windows.Forms.TextBox()
        Me.label12 = New System.Windows.Forms.Label()
        Me.btnJavaScriptSerializer = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.chkMapFilter = New System.Windows.Forms.CheckBox()
        Me.txtResultMax = New System.Windows.Forms.TextBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtResultMin = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.txtMaxY = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.txtMinY = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.txtMaxX = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtMinX = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.cmbSize = New System.Windows.Forms.ComboBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.rbtUserID = New System.Windows.Forms.RadioButton()
        Me.rbtAll = New System.Windows.Forms.RadioButton()
        Me.rbtPublic = New System.Windows.Forms.RadioButton()
        Me.label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtGeonamesUser
        '
        Me.txtGeonamesUser.Location = New System.Drawing.Point(145, 212)
        Me.txtGeonamesUser.Name = "txtGeonamesUser"
        Me.txtGeonamesUser.Size = New System.Drawing.Size(245, 20)
        Me.txtGeonamesUser.TabIndex = 53
        Me.txtGeonamesUser.Text = "demo"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(12, 215)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(113, 13)
        Me.label12.TabIndex = 52
        Me.label12.Text = "Geonames user name:"
        '
        'btnJavaScriptSerializer
        '
        Me.btnJavaScriptSerializer.Location = New System.Drawing.Point(214, 259)
        Me.btnJavaScriptSerializer.Name = "btnJavaScriptSerializer"
        Me.btnJavaScriptSerializer.Size = New System.Drawing.Size(142, 23)
        Me.btnJavaScriptSerializer.TabIndex = 51
        Me.btnJavaScriptSerializer.Text = "JavaScriptSerializer"
        Me.btnJavaScriptSerializer.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(50, 259)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(147, 23)
        Me.btnStart.TabIndex = 50
        Me.btnStart.Text = "DataContractJsonSerializer"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'chkMapFilter
        '
        Me.chkMapFilter.AutoSize = True
        Me.chkMapFilter.Checked = True
        Me.chkMapFilter.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkMapFilter.Location = New System.Drawing.Point(15, 169)
        Me.chkMapFilter.Name = "chkMapFilter"
        Me.chkMapFilter.Size = New System.Drawing.Size(69, 17)
        Me.chkMapFilter.TabIndex = 49
        Me.chkMapFilter.Text = "Map filter"
        Me.chkMapFilter.UseVisualStyleBackColor = True
        '
        'txtResultMax
        '
        Me.txtResultMax.Location = New System.Drawing.Point(278, 129)
        Me.txtResultMax.Name = "txtResultMax"
        Me.txtResultMax.Size = New System.Drawing.Size(112, 20)
        Me.txtResultMax.TabIndex = 48
        Me.txtResultMax.Text = "20"
        Me.txtResultMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(245, 132)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(16, 13)
        Me.label9.TabIndex = 47
        Me.label9.Text = "to"
        '
        'txtResultMin
        '
        Me.txtResultMin.Location = New System.Drawing.Point(115, 129)
        Me.txtResultMin.Name = "txtResultMin"
        Me.txtResultMin.Size = New System.Drawing.Size(111, 20)
        Me.txtResultMin.TabIndex = 46
        Me.txtResultMin.Text = "0"
        Me.txtResultMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(82, 132)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(27, 13)
        Me.label10.TabIndex = 45
        Me.label10.Text = "from"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(12, 132)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(55, 13)
        Me.label11.TabIndex = 44
        Me.label11.Text = "Results #:"
        '
        'txtMaxY
        '
        Me.txtMaxY.Location = New System.Drawing.Point(278, 93)
        Me.txtMaxY.Name = "txtMaxY"
        Me.txtMaxY.Size = New System.Drawing.Size(112, 20)
        Me.txtMaxY.TabIndex = 43
        Me.txtMaxY.Text = "90"
        Me.txtMaxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(245, 96)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(16, 13)
        Me.label6.TabIndex = 42
        Me.label6.Text = "to"
        '
        'txtMinY
        '
        Me.txtMinY.Location = New System.Drawing.Point(115, 93)
        Me.txtMinY.Name = "txtMinY"
        Me.txtMinY.Size = New System.Drawing.Size(111, 20)
        Me.txtMinY.TabIndex = 41
        Me.txtMinY.Text = "-90"
        Me.txtMinY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(82, 96)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(27, 13)
        Me.label7.TabIndex = 40
        Me.label7.Text = "from"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(12, 96)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(48, 13)
        Me.label8.TabIndex = 39
        Me.label8.Text = "Latitude:"
        '
        'txtMaxX
        '
        Me.txtMaxX.Location = New System.Drawing.Point(278, 67)
        Me.txtMaxX.Name = "txtMaxX"
        Me.txtMaxX.Size = New System.Drawing.Size(112, 20)
        Me.txtMaxX.TabIndex = 38
        Me.txtMaxX.Text = "180"
        Me.txtMaxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(245, 70)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(16, 13)
        Me.label5.TabIndex = 37
        Me.label5.Text = "to"
        '
        'txtMinX
        '
        Me.txtMinX.Location = New System.Drawing.Point(115, 67)
        Me.txtMinX.Name = "txtMinX"
        Me.txtMinX.Size = New System.Drawing.Size(111, 20)
        Me.txtMinX.TabIndex = 36
        Me.txtMinX.Text = "-180"
        Me.txtMinX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(82, 70)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(27, 13)
        Me.label4.TabIndex = 35
        Me.label4.Text = "from"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(12, 70)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(57, 13)
        Me.label3.TabIndex = 34
        Me.label3.Text = "Longitude:"
        '
        'cmbSize
        '
        Me.cmbSize.FormattingEnabled = True
        Me.cmbSize.Location = New System.Drawing.Point(85, 34)
        Me.cmbSize.Name = "cmbSize"
        Me.cmbSize.Size = New System.Drawing.Size(305, 21)
        Me.cmbSize.TabIndex = 33
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(12, 37)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(30, 13)
        Me.label2.TabIndex = 32
        Me.label2.Text = "Size:"
        '
        'txtUserID
        '
        Me.txtUserID.Location = New System.Drawing.Point(268, 6)
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.Size = New System.Drawing.Size(122, 20)
        Me.txtUserID.TabIndex = 31
        '
        'rbtUserID
        '
        Me.rbtUserID.AutoSize = True
        Me.rbtUserID.Location = New System.Drawing.Point(198, 7)
        Me.rbtUserID.Name = "rbtUserID"
        Me.rbtUserID.Size = New System.Drawing.Size(64, 17)
        Me.rbtUserID.TabIndex = 30
        Me.rbtUserID.TabStop = True
        Me.rbtUserID.Text = "User-ID:"
        Me.rbtUserID.UseVisualStyleBackColor = True
        '
        'rbtAll
        '
        Me.rbtAll.AutoSize = True
        Me.rbtAll.Location = New System.Drawing.Point(145, 7)
        Me.rbtAll.Name = "rbtAll"
        Me.rbtAll.Size = New System.Drawing.Size(36, 17)
        Me.rbtAll.TabIndex = 29
        Me.rbtAll.TabStop = True
        Me.rbtAll.Text = "All"
        Me.rbtAll.UseVisualStyleBackColor = True
        '
        'rbtPublic
        '
        Me.rbtPublic.AutoSize = True
        Me.rbtPublic.Location = New System.Drawing.Point(85, 7)
        Me.rbtPublic.Name = "rbtPublic"
        Me.rbtPublic.Size = New System.Drawing.Size(61, 17)
        Me.rbtPublic.TabIndex = 28
        Me.rbtPublic.TabStop = True
        Me.rbtPublic.Text = "Popular"
        Me.rbtPublic.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(12, 9)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(26, 13)
        Me.label1.TabIndex = 27
        Me.label1.Text = "Set:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 295)
        Me.Controls.Add(Me.txtGeonamesUser)
        Me.Controls.Add(Me.label12)
        Me.Controls.Add(Me.btnJavaScriptSerializer)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.chkMapFilter)
        Me.Controls.Add(Me.txtResultMax)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.txtResultMin)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.txtMaxY)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.txtMinY)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.txtMaxX)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.txtMinX)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.cmbSize)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtUserID)
        Me.Controls.Add(Me.rbtUserID)
        Me.Controls.Add(Me.rbtAll)
        Me.Controls.Add(Me.rbtPublic)
        Me.Controls.Add(Me.label1)
        Me.Name = "Form1"
        Me.Text = "Panoramio-JSON"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents txtGeonamesUser As System.Windows.Forms.TextBox
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents btnJavaScriptSerializer As System.Windows.Forms.Button
    Private WithEvents btnStart As System.Windows.Forms.Button
    Private WithEvents chkMapFilter As System.Windows.Forms.CheckBox
    Private WithEvents txtResultMax As System.Windows.Forms.TextBox
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents txtResultMin As System.Windows.Forms.TextBox
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents txtMaxY As System.Windows.Forms.TextBox
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents txtMinY As System.Windows.Forms.TextBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents txtMaxX As System.Windows.Forms.TextBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents txtMinX As System.Windows.Forms.TextBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents cmbSize As System.Windows.Forms.ComboBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents txtUserID As System.Windows.Forms.TextBox
    Private WithEvents rbtUserID As System.Windows.Forms.RadioButton
    Private WithEvents rbtAll As System.Windows.Forms.RadioButton
    Private WithEvents rbtPublic As System.Windows.Forms.RadioButton
    Private WithEvents label1 As System.Windows.Forms.Label

End Class
