﻿Public Class PanoramioData

    Public Sub New()
        'nothing to do here
    End Sub

    Public count As Integer
    Public photos As List(Of Photo)
    Public has_more As Boolean
End Class

Public Class Photo
    Public upload_date As String
    Public owner_name As String
    Public photo_id As Integer
    Public longitude As Double
    Public height As Integer
    Public width As Integer
    Public photo_title As String
    Public latitude As Double
    Public owner_url As String
    Public photo_file_url As String
    Public photo_url As String
End Class

Public Enum PhotoSize
    original
    medium
    small
    thumbnail
    square
    mini_square
End Enum
