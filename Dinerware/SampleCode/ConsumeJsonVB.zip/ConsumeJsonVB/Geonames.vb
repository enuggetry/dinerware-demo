﻿Public Class Geoname
    Public countryName As String
    Public adminCode1 As String
    Public fclName As String
    Public countryCode As String
    Public lng As Double
    Public fcodeName As String
    Public distance As String
    Public toponymName As String
    Public fcl As String
    Public name As String
    Public fcode As String
    Public geonameId As Integer
    Public lat As Double
    Public adminName1 As String
    Public population As Integer
End Class

Public Class Geonames
    Public geonames As List(Of Geoname)
End Class

Public Class Status
    Public message As String
    Public value As Integer
End Class

Public Class StatusRootObject
    Public status As Status
End Class