Public Class frmMain

    Dim demos As New ArrayList()
    
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Add all the demos
        demos.Add(New DemoGetClockedInUsers())
        demos.Add(New DemoGetFullMenu())
        demos.Add(New DemoTrialTicket())


        'Add demo names to list
        For Each d As Demo In demos
            lstDemos.Items.Add(d.name)
        Next

        If lstDemos.Items.Count > 0 Then
            lstDemos.SelectedIndex = 0
        End If

    End Sub

    Private Sub btnPlay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPlay.Click
        'run the selected demo

        'make sure a demo is selected
        If (lstDemos.SelectedIndex > -1) Then
            'a demo is selected
            Me.Cursor = Cursors.WaitCursor
            demos(lstDemos.SelectedIndex).Run()
            Me.Cursor = Cursors.Default
        Else
            'no demo is selected
            Microsoft.VisualBasic.MsgBox("Please select a demo from the list.")
        End If
    End Sub

    
    Private Sub btnPlayAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlayAll.Click
        'run all demos

        'make sure there are some
        If (lstDemos.Items.Count > 0) Then
            'there are some
            Dim i As Integer

            For i = 0 To (lstDemos.Items.Count - 1)
                lstDemos.SelectedIndex = i
                Me.Cursor = Cursors.WaitCursor
                demos(lstDemos.SelectedIndex).Run()
                Me.Cursor = Cursors.Default
            Next 'i

        Else
            'WTF where are they
            Microsoft.VisualBasic.MsgBox("No Demos to run.")
        End If
    End Sub
End Class

