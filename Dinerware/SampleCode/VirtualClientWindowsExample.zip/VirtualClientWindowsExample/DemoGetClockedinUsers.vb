'Imports VirtualClientWindowsExample.localhost

Public Class DemoGetClockedInUsers
    Inherits Demo

    Public Sub New()

        name = "Get Clocked in Users"

    End Sub

    Public Overrides Sub Run()

        Dim results() As Object
        'results = VirtualClientWindowsExample.My.WebServices.VirtualClient.GetEmployeesClockedIn()
        results = My.WebServices.VirtualClient.GetEmployeesClockedIn()

        Dim s As String = ""
        Dim o As Object

        For Each o In results
            s = s + o.username + vbCrLf
        Next

        Microsoft.VisualBasic.MsgBox(name + ":" + vbCrLf + s)

    End Sub

End Class
