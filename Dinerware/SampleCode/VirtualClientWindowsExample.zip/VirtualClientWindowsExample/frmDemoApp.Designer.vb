<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDemoApp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lstTickets = New System.Windows.Forms.ListBox
        Me.btnAdd = New System.Windows.Forms.Button
        Me.lstTicketItems = New System.Windows.Forms.ListBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.lstMenuCategories = New System.Windows.Forms.ListBox
        Me.lstCategoryItems = New System.Windows.Forms.ListBox
        Me.lstChoiceCategories = New System.Windows.Forms.ListBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnMenu = New System.Windows.Forms.Button
        Me.btnSendTicket = New System.Windows.Forms.Button
        Me.lstChoiceCategoryItems = New System.Windows.Forms.ListBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Label7 = New System.Windows.Forms.Label
        Me.lstSelectedChoicesForTicketItem = New System.Windows.Forms.ListBox
        Me.btnPaid = New System.Windows.Forms.Button
        Me.lstItemDiscounts = New System.Windows.Forms.ListBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.lstTicketDiscounts = New System.Windows.Forms.ListBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tickets"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(445, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Menu Categories"
        '
        'lstTickets
        '
        Me.lstTickets.FormattingEnabled = True
        Me.lstTickets.Location = New System.Drawing.Point(12, 52)
        Me.lstTickets.Name = "lstTickets"
        Me.lstTickets.Size = New System.Drawing.Size(265, 212)
        Me.lstTickets.TabIndex = 1
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(12, 418)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 2
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lstTicketItems
        '
        Me.lstTicketItems.FormattingEnabled = True
        Me.lstTicketItems.Location = New System.Drawing.Point(286, 52)
        Me.lstTicketItems.Name = "lstTicketItems"
        Me.lstTicketItems.Size = New System.Drawing.Size(153, 212)
        Me.lstTicketItems.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(283, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Ticket Items"
        '
        'lstMenuCategories
        '
        Me.lstMenuCategories.FormattingEnabled = True
        Me.lstMenuCategories.Location = New System.Drawing.Point(448, 52)
        Me.lstMenuCategories.Name = "lstMenuCategories"
        Me.lstMenuCategories.Size = New System.Drawing.Size(156, 160)
        Me.lstMenuCategories.TabIndex = 9
        '
        'lstCategoryItems
        '
        Me.lstCategoryItems.FormattingEnabled = True
        Me.lstCategoryItems.Location = New System.Drawing.Point(448, 246)
        Me.lstCategoryItems.Name = "lstCategoryItems"
        Me.lstCategoryItems.Size = New System.Drawing.Size(156, 160)
        Me.lstCategoryItems.TabIndex = 11
        '
        'lstChoiceCategories
        '
        Me.lstChoiceCategories.FormattingEnabled = True
        Me.lstChoiceCategories.Location = New System.Drawing.Point(610, 52)
        Me.lstChoiceCategories.Name = "lstChoiceCategories"
        Me.lstChoiceCategories.Size = New System.Drawing.Size(156, 160)
        Me.lstChoiceCategories.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(610, 36)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Menu Item's Choices"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(445, 230)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(114, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Category's Menu Items"
        '
        'btnMenu
        '
        Me.btnMenu.Enabled = False
        Me.btnMenu.Location = New System.Drawing.Point(691, 418)
        Me.btnMenu.Name = "btnMenu"
        Me.btnMenu.Size = New System.Drawing.Size(75, 23)
        Me.btnMenu.TabIndex = 18
        Me.btnMenu.Text = "Menu"
        Me.btnMenu.UseVisualStyleBackColor = True
        '
        'btnSendTicket
        '
        Me.btnSendTicket.Enabled = False
        Me.btnSendTicket.Location = New System.Drawing.Point(121, 418)
        Me.btnSendTicket.Name = "btnSendTicket"
        Me.btnSendTicket.Size = New System.Drawing.Size(75, 23)
        Me.btnSendTicket.TabIndex = 4
        Me.btnSendTicket.Text = "Commit"
        Me.btnSendTicket.UseVisualStyleBackColor = True
        '
        'lstChoiceCategoryItems
        '
        Me.lstChoiceCategoryItems.FormattingEnabled = True
        Me.lstChoiceCategoryItems.Location = New System.Drawing.Point(610, 246)
        Me.lstChoiceCategoryItems.Name = "lstChoiceCategoryItems"
        Me.lstChoiceCategoryItems.Size = New System.Drawing.Size(156, 160)
        Me.lstChoiceCategoryItems.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(610, 230)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(132, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Available Choice's Options"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 445)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(780, 22)
        Me.StatusStrip1.TabIndex = 19
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(121, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(780, 24)
        Me.MenuStrip1.TabIndex = 20
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomersToolStripMenuItem, Me.ToolStripMenuItem1, Me.ToolStripMenuItem2, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.CustomersToolStripMenuItem.Text = "&Customers"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(128, 6)
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(128, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(283, 282)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(153, 13)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Ticket Item's Selected Choices"
        '
        'lstSelectedChoicesForTicketItem
        '
        Me.lstSelectedChoicesForTicketItem.FormattingEnabled = True
        Me.lstSelectedChoicesForTicketItem.Location = New System.Drawing.Point(286, 298)
        Me.lstSelectedChoicesForTicketItem.Name = "lstSelectedChoicesForTicketItem"
        Me.lstSelectedChoicesForTicketItem.Size = New System.Drawing.Size(153, 43)
        Me.lstSelectedChoicesForTicketItem.TabIndex = 22
        '
        'btnPaid
        '
        Me.btnPaid.Enabled = False
        Me.btnPaid.Location = New System.Drawing.Point(202, 419)
        Me.btnPaid.Name = "btnPaid"
        Me.btnPaid.Size = New System.Drawing.Size(75, 23)
        Me.btnPaid.TabIndex = 23
        Me.btnPaid.Text = "Paid"
        Me.btnPaid.UseVisualStyleBackColor = True
        '
        'lstItemDiscounts
        '
        Me.lstItemDiscounts.FormattingEnabled = True
        Me.lstItemDiscounts.Location = New System.Drawing.Point(286, 363)
        Me.lstItemDiscounts.Name = "lstItemDiscounts"
        Me.lstItemDiscounts.Size = New System.Drawing.Size(153, 43)
        Me.lstItemDiscounts.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(283, 347)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Ticket Item's Discounts"
        '
        'lstTicketDiscounts
        '
        Me.lstTicketDiscounts.FormattingEnabled = True
        Me.lstTicketDiscounts.Location = New System.Drawing.Point(12, 298)
        Me.lstTicketDiscounts.Name = "lstTicketDiscounts"
        Me.lstTicketDiscounts.Size = New System.Drawing.Size(265, 108)
        Me.lstTicketDiscounts.TabIndex = 27
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 282)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(87, 13)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "Ticket Discounts"
        '
        'frmDemoApp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(780, 467)
        Me.Controls.Add(Me.lstTicketDiscounts)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lstItemDiscounts)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnPaid)
        Me.Controls.Add(Me.lstSelectedChoicesForTicketItem)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lstChoiceCategoryItems)
        Me.Controls.Add(Me.btnSendTicket)
        Me.Controls.Add(Me.btnMenu)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lstChoiceCategories)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lstCategoryItems)
        Me.Controls.Add(Me.lstMenuCategories)
        Me.Controls.Add(Me.lstTicketItems)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.lstTickets)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmDemoApp"
        Me.Text = "Dinerware API Demo Application"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstTickets As System.Windows.Forms.ListBox
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents lstTicketItems As System.Windows.Forms.ListBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lstMenuCategories As System.Windows.Forms.ListBox
    Friend WithEvents lstCategoryItems As System.Windows.Forms.ListBox
    Friend WithEvents lstChoiceCategories As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnMenu As System.Windows.Forms.Button
    Friend WithEvents btnSendTicket As System.Windows.Forms.Button
    Friend WithEvents lstChoiceCategoryItems As System.Windows.Forms.ListBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lstSelectedChoicesForTicketItem As System.Windows.Forms.ListBox
    Friend WithEvents btnPaid As System.Windows.Forms.Button
    Friend WithEvents lstItemDiscounts As System.Windows.Forms.ListBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lstTicketDiscounts As System.Windows.Forms.ListBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CustomersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
End Class
