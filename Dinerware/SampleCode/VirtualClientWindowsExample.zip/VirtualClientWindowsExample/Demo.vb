Public MustInherit Class Demo

    Dim m_name As String

    Public Sub New()
        m_name = "Default"
    End Sub

    Public Sub New(ByVal name As String)
        Me.name = name
    End Sub

    Public MustOverride Sub Run()


    Property name()
        Get
            Return m_name
        End Get
        Set(ByVal value)
            m_name = value
        End Set
    End Property
End Class
