Imports VirtualClientWindowsExample.WebRefDinerware

Public Class DemoGetFullMenu
    Inherits Demo



    Public Sub New()

        name = "Get Full Menu"

    End Sub

    Public Overrides Sub Run()

        Dim result As WebRefDinerware.wsMenu
        'results = VirtualClientWindowsExample.My.WebServices.VirtualClient.GetEmployeesClockedIn()
        result = My.WebServices.VirtualClient.GetMenu()

        Dim sb As New System.Text.StringBuilder
        
        sb.Append(name + ":" + vbCrLf)

        For Each cat As WebRefDinerware.wsCategory In result.CATEGORIES
            sb.Append(cat.NAME + vbCrLf)
            For Each mi As WebRefDinerware.wsMenuItem In cat.MENU_ITEMS
                sb.Append(vbTab + mi.NAME + vbCrLf)
                For Each cc As WebRefDinerware.wsChoiceCategory In mi.CHOICE_CATEGORIES
                    sb.Append(vbTab + vbTab + cc.NAME + vbCrLf)
                    For Each c As WebRefDinerware.wsChoice In cc.CHOICES
                        sb.Append(vbTab + vbTab + vbTab + c.NAME + vbCrLf)
                        'TODO Deal with more possible depth
                    Next
                Next
            Next
        Next

        Microsoft.VisualBasic.MsgBox(sb.ToString)

    End Sub

End Class

