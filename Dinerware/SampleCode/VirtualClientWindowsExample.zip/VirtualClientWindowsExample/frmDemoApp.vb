Imports VirtualClientWindowsExample.WebRefDinerware
Imports System.Collections.ObjectModel

Public Class frmDemoApp


    Dim all_choice_categories As New Collection(Of ChoiceCategory)
    Dim all_choice_options As New List(Of Choice)


    Sub selectAndOrCreateTicket()

        'Add a ticket if there are none
        If lstTickets.SelectedIndex < 0 Then
            If lstTickets.Items.Count = 0 Then
                lstTickets.SelectedIndex = lstTickets.Items.Add(New Ticket())
            Else
                lstTickets.SelectedIndex = lstTickets.Items.Count - 1
            End If
        End If
    End Sub


    Private Sub frmDemoApp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        refeshMenuCategories()

    End Sub

    Sub refeshMenuCategories()

        lstMenuCategories.Items.Clear()

        For Each cat As WebRefDinerware.wsCategory In My.WebServices.VirtualClient.GetMenuCategories()
            lstMenuCategories.Items.Add(New MenuCategory(cat))
        Next

        For Each cc As wsChoiceCategory In My.WebServices.VirtualClient.GetActiveChoiceCategories()
            all_choice_categories.Add(New ChoiceCategory(cc))
        Next

        For Each co As wsChoice In My.WebServices.VirtualClient.GetActiveChoices()
            all_choice_options.Add(New Choice(co))
        Next

    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        lstTickets.SelectedIndex = lstTickets.Items.Add(New Ticket())
    End Sub

    Private Sub lstTicketItems_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTicketItems.SelectedIndexChanged

        lstSelectedChoicesForTicketItem.Items.Clear()

        If -1 = lstTicketItems.SelectedIndex Then
            Exit Sub
        End If

        Me.lstSelectedChoicesForTicketItem.Items.Clear()
        For Each c As Choice In Me.lstTicketItems.SelectedItem.GetAllChoices()
            If (c.Selected) Then
                Me.lstSelectedChoicesForTicketItem.Items.Add(c)
            End If
        Next

        Me.lstItemDiscounts.Items.Clear()

        For Each d As wsDiscount In Me.lstTicketItems.SelectedItem.DISCOUNTS

            Me.lstItemDiscounts.Items.Add(d)

        Next
        'updateTicketItemChoicesFromMenuItem(lstTicketItems.SelectedItem)

    End Sub

    'Function getChoiceByTrialChoice(ByVal ic As Choice) As WebRefDinerware.wsChoice
    '    For Each c As Choice In all_choice_options
    '        If c.ID = ic.ChoiceId Then
    '            Return c
    '        End If
    '    Next
    '    Return Nothing
    'End Function

    'Function getMenuItemByTrialMenuItem(ByVal tmi As WebRefDinerware.wsTrialMenuItem) As WebRefDinerware.wsMenuItem

    '    If tmi Is Nothing Then
    '        Return Nothing
    '    End If


    '    For Each mc As WebRefDinerware.wsCategory In lstMenuCategories.Items
    '        For Each mi As WebRefDinerware.wsMenuItem In mc.MENU_ITEMS
    '            If mi.ID = tmi.ItemID Then
    '                Return mi
    '            End If
    '        Next
    '    Next

    '    Return Nothing
    'End Function


    Private Sub lstMenuCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstMenuCategories.SelectedIndexChanged

        lstCategoryItems.Items.Clear()
        lstChoiceCategories.Items.Clear()
        lstChoiceCategoryItems.Items.Clear()

        If -1 = lstMenuCategories.SelectedIndex Then Exit Sub

        If lstMenuCategories.SelectedItem.MenuItemCollection.Count = 0 Then
            For Each i As wsMenuItem In My.WebServices.VirtualClient.GetMenuItemsForCategory(lstMenuCategories.SelectedItem.ID)
                lstMenuCategories.SelectedItem.MenuItemCollection.Add(New MenuItem(i))
            Next
        End If

        For Each mi As MenuItem In lstMenuCategories.SelectedItem.MenuItemCollection
            lstCategoryItems.Items.Add(mi)
        Next

    End Sub

    Private Sub lstCategoryItems_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstCategoryItems.SelectedIndexChanged
        lstChoiceCategories.Items.Clear()
        lstChoiceCategoryItems.Items.Clear()
        If -1 = lstCategoryItems.SelectedIndex Then Exit Sub
        selectAndOrCreateTicket()

        Dim si As New MenuItem(CType(lstCategoryItems.SelectedItem, MenuItem))

        lstTickets.SelectedItem.MenuItemsCollection.Add(si)
        lstTicketItems.SelectedIndex = lstTicketItems.Items.Add(si)

        'menu_item_choice_categories = lstCategoryItems.SelectedItem.ChoiceCategoryCollection
        For Each choice_cat As ChoiceCategory In lstCategoryItems.SelectedItem.ChoiceCategoryCollection
            lstChoiceCategories.Items.Add(choice_cat)
        Next

        'select the last choice cat
        If lstChoiceCategories.Items.Count > 0 Then
            lstChoiceCategories.SelectedIndex = lstChoiceCategories.Items.Count - 1
        End If


        'TODO Discounts
        'Dim n = 0
        'If mi.DISCOUNTS.Length > 0 Then ReDim tmi.DiscountIds(mi.DISCOUNTS.Length)
        'For Each dis As WebRefDinerware.wsDiscount In mi.DISCOUNTS
        ' tmi.DiscountIds(n) = mi.DISCOUNTS(n).ID
        ' n = n + 1
        ' Next
    End Sub

    Private Sub lstChoiceCategories_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstChoiceCategories.SelectedIndexChanged
        lstChoiceCategoryItems.Items.Clear()
        If -1 = lstChoiceCategories.SelectedIndex Then Exit Sub

        'ReDim Preserve Me.lstTicketItems.SelectedItem.CHOICE_CATEGORIES(Me.lstTicketItems.SelectedItem.CHOICE_CATEGORIES.length - 1)
        'Dim tcc As New WebRefDinerware.wsTrialChoiceCategory
        'tcc.ChoiceCatId = lstChoiceCategories.SelectedItem.ID
        'Me.lstTicketItems.SelectedItem.CHOICE_CATEGORIES(Me.lstTicketItems.SelectedItem.CHOICE_CATEGORIES.length - 1) = cc

        For Each choice_option As Choice In lstChoiceCategories.SelectedItem.ChoiceCollection
            lstChoiceCategoryItems.Items.Add(choice_option)
        Next

    End Sub

    Private Sub lstChoiceCategoryItems_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstChoiceCategoryItems.SelectedIndexChanged

        If -1 = lstChoiceCategories.SelectedIndex Or -1 = lstChoiceCategoryItems.SelectedIndex Then Exit Sub

        ''This creates a copy
        Dim i As New Choice(CType(lstChoiceCategoryItems.SelectedItem, Choice))

        ''This adds it to the list
        Me.lstSelectedChoicesForTicketItem.Items.Add(i)

        ''this adds the same one to the tcket menu item so that when it is deselected and reselected it will show back up in the list
        Me.lstTicketItems.SelectedItem.SetChoice(i)

        ''Add any sub cats to the sub cat list
        If lstChoiceCategoryItems.SelectedItem.ChoiceCategoryCollection.Count > 0 Then

            For Each choice_cat As ChoiceCategory In lstChoiceCategoryItems.SelectedItem.ChoiceCategoryCollection
                lstChoiceCategories.Items.Add(choice_cat)
            Next
            'select the last one added. Could select the required one but the demo app does not need to be that smart.
            lstChoiceCategories.SelectedIndex = lstChoiceCategories.Items.Count - 1
        End If

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub lstTickets_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTickets.SelectedIndexChanged

        If lstTickets.SelectedIndex < 0 Then
            btnSendTicket.Enabled = False
            Exit Sub
        End If

        Dim index As Integer = lstTickets.SelectedIndex

        If Not Me.lstTickets.SelectedItem.Response Is Nothing Then
            btnSendTicket.Enabled = False
            btnPaid.Enabled = True
        Else
            btnSendTicket.Enabled = True
            btnPaid.Enabled = False
        End If

        'lstMenuCategories.Items.Clear()
        'lstCategoryItems.SelectedIndex = -1
        lstTicketItems.Items.Clear()
        If lstTickets.Items.Count = -1 Then Exit Sub

        If lstTickets.SelectedItem.MenuItemsCollection Is Nothing Then
            'Me.ticketItemsVisible = False
            btnSendTicket.Enabled = False
        Else
            For Each ti As MenuItem In lstTickets.SelectedItem.MenuItemsCollection
                lstTicketItems.Items.Add(ti)
            Next
            'Me.ticketItemsVisible = True
            btnSendTicket.Enabled = True

        End If

    End Sub

    Private Sub btnSendTicket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSendTicket.Click

        If lstTickets.SelectedIndex < 0 Then Exit Sub

        Dim t As New WebRefDinerware.wsTrialTicket

        Dim tr As WebRefDinerware.TrialResponse

        t = lstTickets.SelectedItem.getTrialTicket()

        tr = My.WebServices.VirtualClient.TrialCommit(0, t)


        If tr.PendingID > 0 Then
            lstTickets.SelectedItem.Response = tr
        End If

        Dim m As String = ""
        m = m + "Message: " + tr.Message + vbCrLf
        m = m + "PendingID: " + tr.PendingID.ToString + vbCrLf
        m = m + "Result: " + tr.Result.ToString + vbCrLf
        m = m + "TicketTaxTotal: " + tr.TaxTotal.ToString + vbCrLf
        m = m + "TicketTotal: " + tr.TicketTotal.ToString + vbCrLf
        MessageBox.Show(m)

    End Sub

    Private Sub btnPaid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPaid.Click

        If lstTickets.SelectedIndex < 0 Then Exit Sub

        'Dim t As TrialTicket 'WebRefDinerware.wsTrialTicket = lstTickets.SelectedItem

        If lstTickets.SelectedItem.Response Is Nothing Then
            MessageBox.Show("Ticket must be commited for totalling before being paid.")
            Exit Sub
        End If

        Dim transaction As New WebRefDinerware.wsTransaction()
        Dim pid As Integer = lstTickets.SelectedItem.Response.PendingID

        transaction.PaymentAmount = lstTickets.SelectedItem.Response.TicketTotal
        transaction.TenderTypeID = 1
        transaction.TenderType = "credit"
        'Dim result As Integer = My.WebServices.VirtualClient.CommitPendingTicket(pid, transaction)
        Dim result As Integer = My.WebServices.VirtualClient.CommitPendingTicketWithNoTransaction(pid)

        Dim m As String = ""
        m = m + "Result: " + result.ToString + vbCrLf
        MessageBox.Show(m)

    End Sub

    Private Sub lstSelectedChoicesForTicketItem_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstSelectedChoicesForTicketItem.SelectedIndexChanged

    End Sub

    Private Sub CustomersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomersToolStripMenuItem.Click
        'frmCustomers.Show()
    End Sub

    Private Sub btnMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenu.Click

    End Sub
End Class

Public Class Ticket
    Inherits WebRefDinerware.wsTrialTicket

    Public Response As WebRefDinerware.TrialResponse
    Public ResultCode As WebRefDinerware.TrialResultCode
    Public MenuItemsCollection As New Collection(Of MenuItem)

    Public Sub New()
        TicketName = "Ticket " + Now
        CustomerID = 0
        SectionID = 0
        SchemaNumber = 0
        ExpectedTime = Now
    End Sub

    Public Function getTrialTicket() As wsTrialTicket

        Dim t As New wsTrialTicket
        t.CustomerID = Me.CustomerID
        t.ExpectedTime = Me.ExpectedTime
        t.MenuItems = Me.MenuItems
        t.SchemaNumber = Me.SchemaNumber
        t.SectionID = Me.SectionID
        t.TicketDiscountIds = Me.TicketDiscountIds
        t.TicketName = Me.TicketName
        t.WaitUntilPrint = Me.WaitUntilPrint

        'updateMenuItems(t.MenuItems)
        Dim tcs(Me.MenuItemsCollection.Count - 1) As wsTrialMenuItem

        Dim tcsindex As Integer = 0

        For Each tmi As MenuItem In Me.MenuItemsCollection
            tcs(tcsindex) = tmi.GetTrialMenuItem()

            tcs(tcsindex).ChoiceCategories = getWsChoiceCategories(tmi.ChoiceCategoryCollection)
            tcsindex = tcsindex + 1
        Next

        t.MenuItems = tcs
        Return t
    End Function

    Public Function getWsChoiceCategories(ByVal ccc As Collection(Of ChoiceCategory)) As Array '(of , ByVal ccs() As wsTrialChoiceCategory

        'doing these loops twice to get the count right is cheaper than redim-ing inside the loop
        Dim cc_count As Integer = 0
        For Each cc As ChoiceCategory In ccc
            Dim c_count As Integer = 0
            For Each c As Choice In cc.ChoiceCollection
                If c.Selected Then
                    c_count = c_count + 1
                End If
            Next
            If c_count > 0 Then
                cc_count = cc_count + 1
            End If
        Next

        Dim tccs(cc_count - 1) As wsTrialChoiceCategory
        Dim tccsindex As Integer = 0

        For Each cc As ChoiceCategory In ccc
            For Each c As Choice In cc.ChoiceCollection
                If c.Selected Then
                    tccs(tccsindex) = cc.getTrialChoiceCategory()
                    tccs(tccsindex).Choices = getWsChoices(cc.ChoiceCollection)
                    tccsindex = tccsindex + 1
                    'if there is a choice in the cat then we add the cat
                    ' we only want to add the cat once so we exit the c choice for loop
                    Exit For
                End If
            Next
        Next

        Return tccs
    End Function

    Public Function getWsChoices(ByVal cc As Collection(Of Choice)) As Array ', ByVal cs() As wsTrialChoice

        Dim c_count As Integer = 0
        For Each c As Choice In cc
            If c.Selected Then
                c_count = c_count + 1
            End If
        Next

        Dim tcs(c_count - 1) As wsTrialChoice
        Dim tcsindex As Integer = 0

        For Each c As Choice In cc
            If c.Selected Then
                tcs(tcsindex) = c.getTrialChoice()
                tcs(tcsindex).ChoiceCategories = getWsChoiceCategories(c.ChoiceCategoryCollection)
                tcsindex = tcsindex + 1
            End If
        Next
        Return tcs
    End Function


    Public Overrides Function ToString() As String
        If Me.Response Is Nothing Then
            Return Me.TicketName + " (PENDING)"
        Else
            Return Me.TicketName + " (" + Me.Response.TicketTotal + ")"
        End If
    End Function
End Class


Public Class MenuItem
    Inherits WebRefDinerware.wsMenuItem

    Public ResultCode As WebRefDinerware.TrialResultCode
    Public ChoiceCategoryCollection As New Collection(Of ChoiceCategory)
    'Public ChoiceCollection As New Collection(Of Choice)

    Public Sub New(ByVal mi As wsMenuItem)
        CHOICE_CATEGORIES = mi.CHOICE_CATEGORIES
        DESCRIPTION = mi.DESCRIPTION
        DISCOUNTS = mi.DISCOUNTS
        GROSS_PRICE = mi.GROSS_PRICE
        ID = mi.ID
        NET_PRICE = mi.NET_PRICE

        NAME = mi.NAME

        For Each c As wsChoiceCategory In CHOICE_CATEGORIES
            ChoiceCategoryCollection.Add(New ChoiceCategory(c))
        Next
    End Sub

    Public Sub New(ByVal mi As MenuItem)
        CHOICE_CATEGORIES = mi.CHOICE_CATEGORIES
        DESCRIPTION = mi.DESCRIPTION
        DISCOUNTS = mi.DISCOUNTS
        GROSS_PRICE = mi.GROSS_PRICE
        ID = mi.ID
        NET_PRICE = mi.NET_PRICE

        NAME = mi.NAME

        ChoiceCategoryCollection = mi.ChoiceCategoryCollection
        'ChoiceCategoryCollection = mi.ChoiceCollection

    End Sub

    Public Function GetTrialMenuItem()
        Dim tmi As New wsTrialMenuItem
        tmi.ItemID = Me.ID
        'TODO make this recursive and fix types
        'tmi.ChoiceCategories = Me.CHOICE_CATEGORIES
        Return tmi
    End Function

    Public Sub setChoice(ByVal i As Choice)
        For Each c As Choice In GetAllChoices()
            'guids are used to uniquely identify an instance oif a choice in a "choice category"/"choice"  hierarchy
            If c.myGuid = i.myGuid Then

                'set c to a duplicate of i
                'c = New Choice(i)
                c.Selected = True
                'If this is omitted all matches will be replaced which may or may not be better behavior,
                ' but may be slower in long lists
                Exit For

            End If
        Next
    End Sub

    Public Function GetAllChoices() As Collection(Of Choice)
        Dim col As New Collection(Of Choice)
        'enter recursive
        getChoicesFromChoiceCategoryCollection(col, Me.ChoiceCategoryCollection)
        Return col
    End Function

    Public Function GetAllDiscounts() As Collection(Of wsDiscount)
        Dim discs As New Collection(Of wsDiscount)
        For Each d As wsDiscount In Me.DISCOUNTS
            discs.Add(d)
        Next
        Return discs
    End Function

    Public Sub getChoicesFromChoiceCategoryCollection(ByVal col As Collection(Of Choice), ByVal ccs As Collection(Of ChoiceCategory))

        For Each cc As ChoiceCategory In ccs 'lstTicketItems.SelectedItem.ChoiceCategories
            If Not cc Is Nothing Then
                If Not cc.ChoiceCollection Is Nothing Then
                    'recurse
                    Me.getChoicesFromChoices(col, cc.ChoiceCollection)
                End If
            End If
        Next
    End Sub

    Public Sub getChoicesFromChoices(ByVal col As Collection(Of Choice), ByVal cs As Collection(Of Choice))
        For Each c As Choice In cs
            col.Add(c)
            If c.ChoiceCategoryCollection.Count > 0 Then
                'recurse
                Me.getChoicesFromChoiceCategoryCollection(col, c.ChoiceCategoryCollection)
            End If
        Next
    End Sub

    Public Overrides Function ToString() As String
        Return Me.NAME + " " + String.Format("{0:C}", Me.GROSS_PRICE)
    End Function

End Class

Public Class ChoiceCategory
    Inherits WebRefDinerware.wsChoiceCategory

    Public parent As Choice = Nothing
    Public ChoiceCollection As New Collection(Of Choice)

    Public Sub New(ByVal cc As wsChoiceCategory)
        Me.CHOICES = cc.CHOICES
        Me.ID = cc.ID
        Me.NAME = cc.NAME
        Me.REQUIREMENT = cc.REQUIREMENT
        For Each c As wsChoice In CHOICES
            Dim nc As Choice = New Choice(c)
            nc.parent = Me
            ChoiceCollection.Add(nc)
        Next
    End Sub
    Function getTrialChoiceCategory()
        Dim tcc As New wsTrialChoiceCategory
        tcc.ChoiceCatId = Me.ID
        Return tcc
    End Function
    Public Overrides Function ToString() As String
        If parent Is Nothing Then
            Return Me.NAME
        Else
            Return Me.NAME + parent.NAME
        End If
    End Function

End Class

Public Class Choice
    Inherits WebRefDinerware.wsChoice
    Public parent As ChoiceCategory = Nothing
    Public Selected As Boolean = False
    Public myGuid As Guid

    Public ChoiceCategoryCollection As New Collection(Of ChoiceCategory) '(Of ChoiceCategory)

    Public Sub New(ByVal c As wsChoice)
        myGuid = Guid.NewGuid()
        Me.CHOICE_CATEGORIES = c.CHOICE_CATEGORIES
        For Each cc As wsChoiceCategory In c.CHOICE_CATEGORIES
            Me.ChoiceCategoryCollection.Add(New ChoiceCategory(cc))
        Next
        Me.CHOICE_CATEGORIES = c.CHOICE_CATEGORIES
        Me.ID = c.ID
        Me.NAME = c.NAME
        Me.PRICE_MODIFIER = c.PRICE_MODIFIER
        Me.PRICE_MODIFIER_PCT = c.PRICE_MODIFIER_PCT
    End Sub


    Public Sub New(ByVal c As Choice)
        myGuid = c.myGuid
        Me.parent = c.parent
        Me.CHOICE_CATEGORIES = c.CHOICE_CATEGORIES
        For Each cc As wsChoiceCategory In c.CHOICE_CATEGORIES
            Me.ChoiceCategoryCollection.Add(New ChoiceCategory(cc))
        Next
        Me.CHOICE_CATEGORIES = c.CHOICE_CATEGORIES
        Me.ID = c.ID
        Me.NAME = c.NAME
        Me.PRICE_MODIFIER = c.PRICE_MODIFIER
        Me.PRICE_MODIFIER_PCT = c.PRICE_MODIFIER_PCT
    End Sub
    Function getTrialChoice()
        Dim c As New wsTrialChoice
        c.ChoiceId = Me.ID
        Return c
    End Function

    Public Overrides Function ToString() As String
        If PRICE_MODIFIER_PCT Then
            Return Me.NAME + " x " + String.Format("{0:P}", Me.PRICE_MODIFIER_PCT)
        End If
        If PRICE_MODIFIER Then
            Return Me.NAME + " + " + String.Format("{0:C}", Me.PRICE_MODIFIER)
        End If
        Return parent.NAME + " " + Me.NAME

    End Function
End Class

Public Class MenuCategory
    Inherits wsCategory

    Public MenuItemCollection As New Collection(Of MenuItem)

    Public Sub New(ByVal cc As wsCategory)
        For Each mi As wsMenuItem In Me.MenuItemCollection
            MenuItemCollection.Add(New MenuItem(mi))
        Next
        Me.ID = cc.ID
        Me.NAME = cc.NAME
    End Sub

    Public Overrides Function ToString() As String
        Return Me.NAME & Me.MenuItemCollection.Count
    End Function

End Class
