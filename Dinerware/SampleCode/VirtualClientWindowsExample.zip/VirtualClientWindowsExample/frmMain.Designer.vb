<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.lstDemos = New System.Windows.Forms.ListBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnPlay = New System.Windows.Forms.Button
        Me.btnPlayAll = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "API Demos"
        '
        'lstDemos
        '
        Me.lstDemos.FormattingEnabled = True
        Me.lstDemos.Location = New System.Drawing.Point(12, 29)
        Me.lstDemos.Name = "lstDemos"
        Me.lstDemos.Size = New System.Drawing.Size(120, 160)
        Me.lstDemos.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(143, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(149, 95)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "This area displays a description of the selected Demo."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(143, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Description"
        '
        'btnPlay
        '
        Me.btnPlay.Location = New System.Drawing.Point(146, 169)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(146, 23)
        Me.btnPlay.TabIndex = 4
        Me.btnPlay.Text = "Play Selected"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'btnPlayAll
        '
        Me.btnPlayAll.Location = New System.Drawing.Point(146, 140)
        Me.btnPlayAll.Name = "btnPlayAll"
        Me.btnPlayAll.Size = New System.Drawing.Size(146, 23)
        Me.btnPlayAll.TabIndex = 5
        Me.btnPlayAll.Text = "Play All"
        Me.btnPlayAll.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnPlay
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(304, 204)
        Me.Controls.Add(Me.btnPlayAll)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstDemos)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmMain"
        Me.Text = "Dinerware API Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lstDemos As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnPlay As System.Windows.Forms.Button
    Friend WithEvents btnPlayAll As System.Windows.Forms.Button
End Class
