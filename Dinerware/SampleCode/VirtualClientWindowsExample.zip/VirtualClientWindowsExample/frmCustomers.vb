﻿Imports VirtualClientWindowsExample.WebRefDinerware
Imports System.Collections.ObjectModel

Public Class frmCustomers

    Private Sub frmCustomers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        refeshCustomers()

    End Sub

    Sub refeshCustomers()

        lstCustomers.Items.Clear()

        For Each cust As WebRefDinerware.wsPerson In My.WebServices.VirtualClient.FindCustomersByAny(0, "")
            lstCustomers.Items.Add(cust)
        Next

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub lstCustomers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstCustomers.SelectedIndexChanged
        'pgCustomer.d()
    End Sub
End Class