Public Class DemoGetMenu
    Inherits Demo

    Public Sub New()

        name = "Get Menu"

    End Sub

    Public Overrides Sub Run()

        Microsoft.VisualBasic.MsgBox(name)

    End Sub

End Class
