'Imports VirtualClientWindowsExample.localhost
Public Class DemoTrialTicket

    Inherits Demo



    Public Sub New()

        name = "Submit Trial Ticket"

    End Sub

    Public Overrides Sub Run()

        Dim tt As New WebRefDinerware.wsTrialTicket()
        tt.CustomerID = 0

        Dim mis(1) As WebRefDinerware.wsTrialMenuItem

        Dim mi As New WebRefDinerware.wsTrialMenuItem()
        mi.ItemID = 193 '193=bud light
        mis(0) = mi

        tt.MenuItems = mis

        Dim tr As WebRefDinerware.TrialResponse
        Dim s As String = ""

        'results = VirtualClientWindowsExample.My.WebServices.VirtualClient.GetEmployeesClockedIn()
        tr = My.WebServices.VirtualClient.TrialCommit(0, tt)
        s = s + tr.Result.ToString()
        Microsoft.VisualBasic.MsgBox("Response:" + vbCrLf + s)

    End Sub

End Class

